<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'id18999226_scandiweb_tam');
  define('DB_PASS', 'd*0Ve721x+vvYy&<');
  define('DB_NAME', 'id18999226_scandiweb');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'https://scandiweb-junior-web-dev.000webhostapp.com/');
  // Site Name
  define('SITENAME', 'Scandiweb Test Website');
  // App Version
  define('APPVERSION', '1.0.0');